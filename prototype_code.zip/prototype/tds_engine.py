"""
TDS Gatekeeper - deterministic core (prototype).

Design rule: the model never produces money. It only proposes a *class* of payment.
Everything below is plain code + a human-maintained rule table.

Jurisdiction: India, resident payees, non-salary TDS only.
Law switch: payment/credit on or before 31-Mar-2026 -> Income-tax Act 1961 (s.194x);
            on or after 01-Apr-2026 -> Income-tax Act 2025 (s.393 table items).
All data used by the tests is SYNTHETIC.
"""
from dataclasses import dataclass
from datetime import date

LAW_SWITCH = date(2026, 4, 1)

# Human-maintained rule cards. Each card is effective-dated and carries its source.
# ref_verified=False means a human has not yet confirmed the ITA-2025 table-item reference
# against the Act text; such cards can compute but can never be auto-cleared.
RULES = {
    "CONTRACT": dict(old="s.194C", new="s.393(1) Table Sl.6(i)", ref_verified=True,
                     rate_ind=1.0, rate_other=2.0, trigger="single_or_aggregate",
                     single=30_000, aggregate=100_000,
                     src="Finance Act 2025 thresholds; ITA-2025 mapping per CBDT FAQ"),
    "PROF":     dict(old="s.194J(b)", new="s.393(1) Table Sl.6(iii)", ref_verified=False,
                     rate_ind=10.0, rate_other=10.0, trigger="aggregate", aggregate=50_000,
                     src="Finance Act 2025 (threshold 30k->50k); item letter to confirm"),
    "TECH":     dict(old="s.194J(a)", new="s.393(1) Table Sl.6(iii)", ref_verified=False,
                     rate_ind=2.0, rate_other=2.0, trigger="aggregate", aggregate=50_000,
                     src="as above"),
    "RENT_PM":  dict(old="s.194I(a)", new="s.393(1) Table Sl.2 (item to confirm)", ref_verified=False,
                     rate_ind=2.0, rate_other=2.0, trigger="monthly", monthly=50_000,
                     src="Finance Act 2025 (annual 2.4L -> 50k per month)"),
    "RENT_LB":  dict(old="s.194I(b)", new="s.393(1) Table Sl.2 (item to confirm)", ref_verified=False,
                     rate_ind=10.0, rate_other=10.0, trigger="monthly", monthly=50_000,
                     src="as above"),
    "COMM":     dict(old="s.194H", new="s.393(1) (item to confirm)", ref_verified=False,
                     rate_ind=2.0, rate_other=2.0, trigger="aggregate", aggregate=20_000,
                     src="rate 5%->2% from 1-Oct-2024"),
}
NO_PAN_RATE = 20.0  # s.206AA (1961) / s.397(2) (2025): higher of 20% and applicable rate


@dataclass
class Result:
    cls: str
    law: str
    section: str
    base_excl_gst: float
    taxable_base: float
    rate: float
    tds: int
    note: str
    ref_verified: bool


def law_for(d: date) -> str:
    return "ITA2025" if d >= LAW_SWITCH else "ITA1961"


def compute(case: dict, cls: str) -> Result:
    rule = RULES[cls]
    d = date.fromisoformat(case["date"])
    law = law_for(d)
    section = rule["new"] if law == "ITA2025" else rule["old"]

    # 1. Base: exclude GST only if shown separately (CBDT Circular 23/2017)
    if case["gst_shown_separately"]:
        base = case["invoice_total"] - case["gst_amount"]
        note = "GST excluded (shown separately). "
    else:
        base = case["invoice_total"]
        note = "GST not separately shown: TDS on full amount. "

    # 2. Threshold / trigger
    prior = case.get("prior_undeducted_ytd", 0)
    taxable = 0.0
    t = rule["trigger"]
    if t == "single_or_aggregate":
        if base > rule["single"]:
            taxable = base
        elif prior + base > rule["aggregate"]:
            taxable = prior + base   # catch-up on crossing (practice; rule card needs CA sign-off)
            note += "Aggregate threshold crossed: catch-up on earlier payments. "
    elif t == "aggregate":
        if prior + base > rule["aggregate"]:      # statute says 'exceeds'
            taxable = prior + base
            if prior:
                note += "Aggregate threshold crossed: catch-up. "
    elif t == "monthly":
        if base > rule["monthly"]:
            taxable = base
    if taxable == 0:
        note += "Below threshold: no TDS. "

    # 3. Rate
    rate = rule["rate_ind"] if case["payee_type"] == "individual" else rule["rate_other"]
    if not case["payee_has_pan"]:
        rate = max(rate, NO_PAN_RATE)
        note += "No PAN: 20%. "

    tds = int(round(taxable * rate / 100.0))   # tax rounded to nearest rupee
    return Result(cls, law, section, base, taxable, rate, tds, note.strip(), rule["ref_verified"])
