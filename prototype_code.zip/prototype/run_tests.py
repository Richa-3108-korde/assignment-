"""Runs 17 synthetic cases two ways:
 A) engine-only: gold class -> deterministic engine -> compare TDS with hand-computed gold
 B) end-to-end with a NON-AI keyword baseline classifier (what the AI stage must beat)
"""
import json, re, sys
from tds_engine import compute

cases = json.load(open("cases.json"))

# Naive keyword baseline (written by me after seeing the cases: deliberately generous to the non-AI side)
PATTERNS = [
    ("PROF", r"audit|legal|advocate|consult|architect|professional"),
    ("COMM", r"brokerage|commission"),
    ("CONTRACT", r"housekeeping|fabrication|labour|contract|maintenance"),
    ("RENT_PM", r"plant|machinery"),
    ("RENT_LB", r"\brent"),
]
def baseline(desc):
    d = desc.lower()
    for cls, pat in PATTERNS:
        if re.search(pat, d):
            return cls
    return "REVIEW"

# ---- A) engine-only
print("A) ENGINE ONLY (gold class given)")
okA = n = 0
for c in cases:
    if c["gold_class"] == "REVIEW":
        continue
    n += 1
    r = compute(c, c["gold_class"])
    ok = r.tds == c["gold_tds"]
    okA += ok
    print(f'  #{c["id"]:>2} {c["gold_class"]:<8} {r.section:<28} base={r.taxable_base:>9,.0f} rate={r.rate:>4}% tds={r.tds:>6,} gold={c["gold_tds"]:>6,} {"OK" if ok else "FAIL"}')
print(f"  -> {okA}/{n} correct\n")

# ---- B) end-to-end baseline
print("B) END-TO-END with keyword baseline")
buckets = {"correct": [], "wrong_confident": [], "needless_escalation": [], "correct_escalation": []}
for c in cases:
    pred = baseline(c["desc"])
    gold = c["gold_class"]
    if pred == "REVIEW":
        (buckets["correct_escalation"] if gold == "REVIEW" else buckets["needless_escalation"]).append(c["id"])
        print(f'  #{c["id"]:>2} baseline=REVIEW  gold={gold}')
        continue
    r = compute(c, pred)
    if gold == "REVIEW":
        buckets["wrong_confident"].append(c["id"])
        print(f'  #{c["id"]:>2} baseline={pred:<8} tds={r.tds:>6,} gold=REVIEW -> confident answer where a human was needed')
    elif r.tds == c["gold_tds"] and pred == gold:
        buckets["correct"].append(c["id"])
        print(f'  #{c["id"]:>2} baseline={pred:<8} tds={r.tds:>6,} OK')
    else:
        buckets["wrong_confident"].append(c["id"])
        print(f'  #{c["id"]:>2} baseline={pred:<8} tds={r.tds:>6,} gold={c["gold_tds"]:>6,} ({gold}) WRONG')
print()
for k, v in buckets.items():
    print(f"  {k:<20} {len(v):>2}  {v}")
