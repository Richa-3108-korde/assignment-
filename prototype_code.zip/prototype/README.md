# TDS Gatekeeper - prototype

Smallest thing that shows the design: the deterministic core (rule cards + calculator) and the
non-AI baseline the AI classification stage has to beat.

Jurisdiction: India, resident payees, non-salary TDS. All 17 invoices in `cases.json` are SYNTHETIC.
Rules reflect FY 2025-26 / Tax Year 2026-27 thresholds as read from secondary sources; ITA-2025 table-item
references marked `ref_verified=False` in `tds_engine.py` have NOT been checked against the Act text.

## Run
    python3 run_tests.py            # needs only Python 3.9+, no API key
    python3 make_diagram.py         # optional, needs matplotlib

## What is tested
A) engine-only: gold class -> engine -> TDS vs hand-computed gold (14 non-review cases)
B) end-to-end with a keyword baseline classifier (17 cases)

## NOT done
The LLM extraction/classification stage is specified in the brief but was NOT run here (no model call in
the prototype). Result B is the gap that stage is meant to close, not evidence that it closes it.
If you add it, use an OpenRouter free-tier model and record the model name here.
