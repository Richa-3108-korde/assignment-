import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

AI, CODE, HUMAN, DATA = "#cfe0f7", "#e3e3e3", "#fbd9b5", "#d5ecd0"
EDGE = {"AI": "#2f6db5", "CODE": "#6b6b6b", "HUMAN": "#c4701a", "DATA": "#3f8f3a"}
fig, ax = plt.subplots(figsize=(8.6, 4.0), dpi=220)
ax.set_xlim(0, 116); ax.set_ylim(-6, 39); ax.axis("off")

def box(x, y, w, h, title, sub, kind):
    col = {"AI": AI, "CODE": CODE, "HUMAN": HUMAN, "DATA": DATA}[kind]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=1.2",
                                fc=col, ec=EDGE[kind], lw=1.3))
    ax.text(x + w / 2, y + h - 2.4, title, ha="center", va="top", fontsize=7.2, fontweight="bold")
    ax.text(x + w / 2, y + h - 6.0, sub, ha="center", va="top", fontsize=5.9, linespacing=1.25)

def arrow(p, q, txt=None, rad=0.0, tx=0, ty=1.2):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=8, lw=1.0, color="#333",
                                 connectionstyle=f"arc3,rad={rad}"))
    if txt:
        ax.text((p[0] + q[0]) / 2 + tx, (p[1] + q[1]) / 2 + ty, txt, fontsize=5.6, ha="center", style="italic")

# Row 1
box(1, 24, 21, 13, "INPUTS", "invoice text / PDF\nvendor master (type, PAN y/n)\nvendor YTD ledger\n(synthetic in prototype)", "DATA")
box(27, 24, 24, 13, "1  EXTRACT  (AI)", "JSON: lines, amounts, GST,\ndates. Every field carries a\nverbatim quote from the invoice", "AI")
box(56, 24, 25, 13, "2  CLASSIFY  (AI)", "closed label set + REVIEW\nreads rule cards only (no memory)\nreturns label + evidence quote\nNO numbers allowed in schema", "AI")
box(86, 24, 28, 13, "3  GATE  (code)", "quotes found in source? totals tie?\ntwo prompts agree? label not\n'contested'? rule card verified?\nelse -> REVIEW", "CODE")
# Row 2 (flows right to left)
box(1, 2, 24, 14, "RULE CARDS (human)", "effective-dated, source-linked\nlaw switch: 1961 Act / 2025 Act\nCA-reviewed; change monitor\nre-runs regression suite", "DATA")
box(29, 2, 24, 14, "6  EVIDENCE LOG", "append-only: invoice hash, quotes,\nlabel, model+prompt version, rule\nversion, engine output, reviewer", "DATA")
box(57, 2, 25, 14, "5  HUMAN REVIEW", "AP clerk approves routine items\nCA decides REVIEW items\n(AMC, software, mixed invoices)\nCA signs quarterly return", "HUMAN")
box(86, 2, 28, 14, "4  COMPUTE  (code)", "GST base -> threshold (uses ledger)\n-> rate (PAN) -> rounding\nTDS amount + citation\n(reads the same rule cards)", "CODE")

arrow((22.5, 30.5), (26.5, 30.5))
arrow((51.5, 30.5), (55.5, 30.5))
arrow((81.5, 30.5), (85.5, 30.5))
arrow((104, 23.6), (104, 16.6), "pass", tx=3.5, ty=0)
arrow((90, 23.6), (76, 16.6), "REVIEW / abstain", rad=0.0, tx=-9, ty=1.0)
arrow((85.5, 9), (82.5, 9), None)
arrow((56.5, 9), (53.5, 9))
ax.add_patch(FancyArrowPatch((20, 16.6), (62, 23.6), arrowstyle="-|>", mutation_scale=8, lw=0.9,
             color="#3f8f3a", linestyle="--", connectionstyle="arc3,rad=-0.12"))
ax.text(47, 18.0, "rules the model may read", fontsize=5.4, ha="center", style="italic", color="#3f8f3a")
ax.text(58, -1.2, "Reviewer overrides become labelled examples for the regression / eval set", fontsize=5.6,
        ha="center", style="italic")
for i, (k, lab) in enumerate([("AI", "AI (probabilistic)"), ("CODE", "Deterministic code"),
                              ("HUMAN", "Human"), ("DATA", "Data / knowledge store")]):
    col = {"AI": AI, "CODE": CODE, "HUMAN": HUMAN, "DATA": DATA}[k]
    ax.add_patch(FancyBboxPatch((1 + i * 17, -4.6), 2.6, 2.0, boxstyle="round,pad=0.1", fc=col, ec=EDGE[k], lw=1))
    ax.text(4.4 + i * 17, -3.6, lab, fontsize=5.8, va="center")
plt.savefig("/home/claude/prototype/architecture.png", bbox_inches="tight", pad_inches=0.04)
